﻿using QuadDevWilwf.CommonForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuadDevWilwf.GuardianForms
{
    public partial class frmGuardMain : Form
    {
        public frmGuardMain()
        {
            InitializeComponent();
        }

        private void btnFlashCards_Click(object sender, EventArgs e)
        {
            //pass details of the parent and child linked accounts
            frmFlashCards flash = new frmFlashCards();
            flash.Show();
            Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            //returns the user to login page.
            frmLogin log = new frmLogin();
            log.Show();
            Hide();
        }

        private void btnProgress_Click(object sender, EventArgs e)
        {
            frmProgressReport prog = new frmProgressReport();
            prog.Show();
            Hide();
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            //show the edit details panel
            frmEditDetails edit = new frmEditDetails();
            edit.Show();
            Hide();
        }
    }
}
