﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuadDevWilwf.GuardianForms
{
    public partial class frmFlashCards : Form
    {
        public frmFlashCards()
        {
            InitializeComponent();
        }

        private void pbReturn_Click(object sender, EventArgs e)
        {
            //returning to main page. either update the database here with progress or 
            //create method in main to update with feedback.
            frmGuardMain main = new frmGuardMain();
            main.Show();
            Hide();
        }
    }
}
