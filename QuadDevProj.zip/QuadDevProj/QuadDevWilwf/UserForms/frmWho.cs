﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuadDevWilwf
{
    public partial class frmWho : Form
    {
        public frmWho()
        {
            InitializeComponent();
        }

        private void pbReturn_Click(object sender, EventArgs e)
        {
            //returning to main page. either update the database here with progress or 
            //create method in main to update with feedback.
            frmMain main = new frmMain();
            main.Show();
            Hide();
        }

        //maybe create a method that always updates user after each level? maybe separate 
        //class does this to allow all games to access it? -- probably better idea
    }
}
