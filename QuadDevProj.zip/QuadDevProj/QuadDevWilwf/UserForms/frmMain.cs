﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuadDevWilwf
{
    public partial class frmMain : Form
    {
        //create a global user details
        public frmMain()
        {
            //recieve the user details
            InitializeComponent();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            //expand this to actually log the user out and potentially save any data
            //that is outstanding e.g. progress report
            frmLogin log = new frmLogin();
            log.Show();
            Hide();
        }

        private void btnNumberGame_Click(object sender, EventArgs e)
        {
            //send the user details to allow updating database
            frmNumbers numgame = new frmNumbers();
            numgame.Show();
            Hide();
        }

        private void btnColorMatch_Click(object sender, EventArgs e)
        {
            //send the user details to allow updating database
            frmColor color = new frmColor();
            color.Show();
            Hide();
        }

        private void btnWho_Click(object sender, EventArgs e)
        {
            //send the user details to allow updating database
            frmWho who = new frmWho();
            who.Show();
            Hide();
        }

        private void btnScience_Click(object sender, EventArgs e)
        {
            //send the user details to allow updating database
            frmScience science = new frmScience();
            science.Show();
            Hide();
        }

        private void btnShopping_Click(object sender, EventArgs e)
        {
            //send the user details to allow updating database
            frmShopping shop = new frmShopping();
            shop.Show();
            Hide();
        }


        //use a method to send all the user details to the game to allow updating database
    }
}
