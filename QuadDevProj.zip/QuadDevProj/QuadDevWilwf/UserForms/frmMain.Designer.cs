﻿namespace QuadDevWilwf
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnLogout = new System.Windows.Forms.Button();
            this.fileSystemWatcher1 = new System.IO.FileSystemWatcher();
            this.btnNumberGame = new System.Windows.Forms.Button();
            this.btnColorMatch = new System.Windows.Forms.Button();
            this.btnWho = new System.Windows.Forms.Button();
            this.btnScience = new System.Windows.Forms.Button();
            this.btnShopping = new System.Windows.Forms.Button();
            this.pbUserLevel = new System.Windows.Forms.PictureBox();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.lblText = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUserLevel)).BeginInit();
            this.SuspendLayout();
            // 
            // btnLogout
            // 
            this.btnLogout.Location = new System.Drawing.Point(650, 395);
            this.btnLogout.Name = "btnLogout";
            this.btnLogout.Size = new System.Drawing.Size(138, 43);
            this.btnLogout.TabIndex = 0;
            this.btnLogout.Text = "Log Out";
            this.btnLogout.UseVisualStyleBackColor = true;
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);
            // 
            // fileSystemWatcher1
            // 
            this.fileSystemWatcher1.EnableRaisingEvents = true;
            this.fileSystemWatcher1.SynchronizingObject = this;
            // 
            // btnNumberGame
            // 
            this.btnNumberGame.Location = new System.Drawing.Point(242, 186);
            this.btnNumberGame.Name = "btnNumberGame";
            this.btnNumberGame.Size = new System.Drawing.Size(326, 34);
            this.btnNumberGame.TabIndex = 1;
            this.btnNumberGame.Text = "Play Number game!";
            this.btnNumberGame.UseVisualStyleBackColor = true;
            this.btnNumberGame.Click += new System.EventHandler(this.btnNumberGame_Click);
            // 
            // btnColorMatch
            // 
            this.btnColorMatch.Location = new System.Drawing.Point(242, 226);
            this.btnColorMatch.Name = "btnColorMatch";
            this.btnColorMatch.Size = new System.Drawing.Size(326, 34);
            this.btnColorMatch.TabIndex = 2;
            this.btnColorMatch.Text = "Play Memory Game!";
            this.btnColorMatch.UseVisualStyleBackColor = true;
            this.btnColorMatch.Click += new System.EventHandler(this.btnColorMatch_Click);
            // 
            // btnWho
            // 
            this.btnWho.Location = new System.Drawing.Point(242, 266);
            this.btnWho.Name = "btnWho";
            this.btnWho.Size = new System.Drawing.Size(326, 34);
            this.btnWho.TabIndex = 3;
            this.btnWho.Text = "Play Who-is-Who!";
            this.btnWho.UseVisualStyleBackColor = true;
            this.btnWho.Click += new System.EventHandler(this.btnWho_Click);
            // 
            // btnScience
            // 
            this.btnScience.Location = new System.Drawing.Point(242, 306);
            this.btnScience.Name = "btnScience";
            this.btnScience.Size = new System.Drawing.Size(326, 34);
            this.btnScience.TabIndex = 4;
            this.btnScience.Text = "Play Science Game!";
            this.btnScience.UseVisualStyleBackColor = true;
            this.btnScience.Click += new System.EventHandler(this.btnScience_Click);
            // 
            // btnShopping
            // 
            this.btnShopping.Location = new System.Drawing.Point(242, 346);
            this.btnShopping.Name = "btnShopping";
            this.btnShopping.Size = new System.Drawing.Size(326, 34);
            this.btnShopping.TabIndex = 5;
            this.btnShopping.Text = "Play Let\'s go Shopping!";
            this.btnShopping.UseVisualStyleBackColor = true;
            this.btnShopping.Click += new System.EventHandler(this.btnShopping_Click);
            // 
            // pbUserLevel
            // 
            this.pbUserLevel.Location = new System.Drawing.Point(242, 55);
            this.pbUserLevel.Name = "pbUserLevel";
            this.pbUserLevel.Size = new System.Drawing.Size(326, 116);
            this.pbUserLevel.TabIndex = 6;
            this.pbUserLevel.TabStop = false;
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.Location = new System.Drawing.Point(321, 9);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(167, 17);
            this.lblWelcome.TabIndex = 7;
            this.lblWelcome.Text = "Welcome such-and-such!";
            // 
            // lblText
            // 
            this.lblText.AutoSize = true;
            this.lblText.Location = new System.Drawing.Point(301, 26);
            this.lblText.Name = "lblText";
            this.lblText.Size = new System.Drawing.Size(216, 17);
            this.lblText.TabIndex = 8;
            this.lblText.Text = "What would you like to do today?";
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lblText);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.pbUserLevel);
            this.Controls.Add(this.btnShopping);
            this.Controls.Add(this.btnScience);
            this.Controls.Add(this.btnWho);
            this.Controls.Add(this.btnColorMatch);
            this.Controls.Add(this.btnNumberGame);
            this.Controls.Add(this.btnLogout);
            this.Name = "frmMain";
            this.Text = "frmMain";
            ((System.ComponentModel.ISupportInitialize)(this.fileSystemWatcher1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbUserLevel)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLogout;
        private System.IO.FileSystemWatcher fileSystemWatcher1;
        private System.Windows.Forms.Label lblText;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.PictureBox pbUserLevel;
        private System.Windows.Forms.Button btnShopping;
        private System.Windows.Forms.Button btnScience;
        private System.Windows.Forms.Button btnWho;
        private System.Windows.Forms.Button btnColorMatch;
        private System.Windows.Forms.Button btnNumberGame;
    }
}