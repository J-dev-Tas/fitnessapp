﻿using QuadDevWilwf.AdminForms;
using QuadDevWilwf.GuardianForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using System.Data.SqlClient;

namespace QuadDevWilwf
{
    public partial class frmLogin : Form
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "7TqpLgOXf8CT8zUivKQlnu1IRCbM8pFWVQf7kp7s",
            BasePath = "https://test-fb5f3.firebaseio.com/"

        };
        IFirebaseClient client;
        public frmLogin()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmRegister reg = new frmRegister();
            reg.Show();
            Hide();
        }

        private async void button1_Click(object sender, EventArgs e)
        {
            /*string strUserType = "admin";
            //if statemement true the login update this
            if (strUserType=="user")
            { 
                //use methods to figure out user type login redirect accordingly
                frmMain main = new frmMain(); //query with Tendesai
                main.Show();
                Hide();
                //else display error
                lblError.Text = "hello im an error";
            }
            else if (strUserType=="parent")
            {
                //navigates to parents page on parent login
                frmGuardMain guard = new frmGuardMain();
                guard.Show();
                Hide();
            }
            else
            {
                //admin login here
                frmAdminMain admin = new frmAdminMain();
                admin.Show();
                Hide();
            }
            var data = new Data
            {
                Username = txtUsername.Text,
                Password = txtPassword.Text
            };

            SetResponse response = await client.SetTaskAsync("User/"+ txtUsername.Text,data);
            Data result = response.ResultAs<Data>();
            MessageBox.Show("Item added");*/
            SqlConnection con = new SqlConnection(@"Data Source=DESKTOP-PC3B2I2\SQLEXPRESS2012;Initial Catalog=WILQD;Integrated Security=True");
            con.Open();

            SqlCommand sqlCom = new SqlCommand("select count(1) from students where username = @usernamee AND spassword = @passwordd", con);
            sqlCom.Parameters.AddWithValue("@usernamee", txtUsername.Text.Trim());
            sqlCom.Parameters.AddWithValue("@passwordd", txtPassword.Text.Trim());
            SqlDataAdapter da = new SqlDataAdapter(sqlCom);
            DataTable dt = new DataTable();
            da.Fill(dt);
            
            
            int count = Convert.ToInt32(sqlCom.ExecuteScalar());
            if (count == 1)
            {
                frmMain main = new frmMain();
                main.Show();
                Hide();
                con.Close();

            }
            else
            {
                MessageBox.Show("Incorrect Username or password");
            }


            }

        private void frmLogin_Load(object sender, EventArgs e)
        {
            /*client = new FireSharp.FirebaseClient(config);
            if (client != null)
            {
                MessageBox.Show("Connection successful");
            }
            else
            {
                MessageBox.Show("Connection unsuccessful");
            }
            */

        }
    }
}
