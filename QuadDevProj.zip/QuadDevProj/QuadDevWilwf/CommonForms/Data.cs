﻿namespace QuadDevWilwf
{
    internal class Data
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }
}