﻿using QuadDevWilwf.AdminForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuadDevWilwf.GuardianForms
{
    public partial class frmEditDetails : Form
    {
        public frmEditDetails()
        {
            InitializeComponent();
        }

        private void pbReturn_Click(object sender, EventArgs e)
        {
            //returning to main page. either update the database here with progress or 
            //create method in main to update with feedback.
            string strUserType = "admin";
            //if statement to determine admin/parent and navigate to correct page
            if (strUserType == "admin") {
                //decide what page to navigate to.
                frmAdminMain admin = new frmAdminMain();
                admin.Show();
            } else
            {
                //go back to parent page
            frmGuardMain main = new frmGuardMain();
            main.Show();
            }
            Hide();
        }
    }
}
