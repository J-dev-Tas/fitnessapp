﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace QuadDevWilwf
{
    public partial class frmRegister : Form
    {
        SqlConnection con = new SqlConnection("Data Source=DESKTOP-PC3B2I2\\SQLEXPRESS2012;Initial Catalog=WILQD;Integrated Security=True");
        //SqlConnection connection = new SqlConnection(connectionstring);


        public frmRegister()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmLogin log = new frmLogin();
            log.Show();
            Hide();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            con.Open();
            //if statemement true the login
            //frmMain main = new frmMain(); //query with Tendesai
            // main.Show();
            //Hide();
            //else display error
            //lblGuardianError.Text = "hello im an error";
            //lblStudentError.Text = "hello im an error";

            String query = "INSERT INTO students (username,sfirstname,slastname,spassword) VALUES (@username,@sf,@sln,@spassword)";
            String query2 = "INSERT INTO guardian (gfirstname,glastname,gemail,gpassword) VALUES (@gf,@gln,@gemail,@gpassword)";
            SqlCommand command = new SqlCommand(query, con);
            SqlCommand command2 = new SqlCommand(query2, con);

            command2.Parameters.AddWithValue("@gf", textBox9.Text.ToString());
            command2.Parameters.AddWithValue("@gln", textBox8.Text.ToString());
            command2.Parameters.AddWithValue("@gemail", textBox10.Text.ToString());
            command2.Parameters.AddWithValue("@gpassword", textBox7.Text.ToString());
            if (textBox7.Text.ToString() == textBox6.Text.ToString())
            {
                command2.ExecuteNonQuery();
                MessageBox.Show("Guardian inserted");
                
            }
            else
            {
                MessageBox.Show("Error");
            }

            command.Parameters.AddWithValue("@username", textBox1.Text.ToString());
            command.Parameters.AddWithValue("@sf", textBox2.Text.ToString());
            command.Parameters.AddWithValue("@sln", textBox3.Text.ToString());
            command.Parameters.AddWithValue("@spassword", textBox4.Text.ToString());
            if(textBox4.Text.ToString() == textBox5.Text.ToString())
            {
                command.ExecuteNonQuery();
                MessageBox.Show("Data inserted");
                con.Close();

                
            }
            else
            {
                MessageBox.Show("Error");
            }

            





        }

    }
}
