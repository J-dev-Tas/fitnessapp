﻿using QuadDevWilwf.AdminForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuadDevWilwf.CommonForms
{
    public partial class frmProgressReport : Form
    {
        public frmProgressReport()
        {
            InitializeComponent();
        }

        private void pbReturn_Click(object sender, EventArgs e)
        {
            //returning to main page. either update the database here with progress or 
            //create method in main to update with feedback.
            string strUserType = "admin";
            //if statement to determine admin/parent and navigate to correct page
            if (strUserType == "admin")
            {
                //decide what page to navigate to.
                frmAdminMain admin = new frmAdminMain();
                admin.Show();
            }
            else
            {
                GuardianForms.frmGuardMain main = new GuardianForms.frmGuardMain();
                main.Show();
            }
            Hide();
        }
    }
}
