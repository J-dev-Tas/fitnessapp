﻿using QuadDevWilwf.CommonForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuadDevWilwf.AdminForms
{
    public partial class frmStudProg : Form
    {
        public frmStudProg()
        {
            InitializeComponent();
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            //view progress report for selected student, pass the selected student.
            frmProgressReport prog = new frmProgressReport();
            prog.Show();
            Hide();
        }
    }
}
