﻿using QuadDevWilwf.GuardianForms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuadDevWilwf.AdminForms
{
    public partial class frmAccounts : Form
    {
        public frmAccounts()
        {
            InitializeComponent();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            //delete the user that is selected but prompt the admin that this cannot be 
            //undone once completed.
        }

        private void btnEdit_Click(object sender, EventArgs e)
        {
            //form needs to recieve selected member.
            frmEditDetails edit = new frmEditDetails();
            edit.Show();
            Hide();
        }

        private void pbReturn_Click(object sender, EventArgs e)
        {
            //navigates back to admin page
            frmAdminMain admin = new frmAdminMain();
            admin.Show();
            Hide();
        }
    }
}
