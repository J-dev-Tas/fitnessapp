﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QuadDevWilwf.AdminForms
{
    public partial class frmAdminMain : Form
    {
        public frmAdminMain()
        {
            InitializeComponent();
        }

        private void btnEditUsers_Click(object sender, EventArgs e)
        {
            //navigates to a gridview with all user details.
            frmAccounts acc = new frmAccounts();
            acc.Show();
            Hide();
        }

        private void btnProgress_Click(object sender, EventArgs e)
        {
            //navigate to select a student
            frmStudProg prog = new frmStudProg();
            prog.Show();
            Hide();
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            //expand this to actually log the user out and potentially save any data
            //that is outstanding e.g. progress report
            frmLogin log = new frmLogin();
            log.Show();
            Hide();
        }
    }
}
